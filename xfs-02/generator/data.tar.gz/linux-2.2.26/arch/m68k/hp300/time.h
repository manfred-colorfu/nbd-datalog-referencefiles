extern void hp300_sched_init(void (*vector)(int, void *, struct pt_regs *));
extern unsigned long hp300_gettimeoffset (void);


