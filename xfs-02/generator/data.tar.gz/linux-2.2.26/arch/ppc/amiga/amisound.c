#include "../../m68k/amiga/amisound.c"
