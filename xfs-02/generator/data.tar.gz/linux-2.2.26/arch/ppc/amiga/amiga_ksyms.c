#include "../../m68k/amiga/amiga_ksyms.c"
