
#ifndef _PPC_KERNEL_PPC8xx_H
#define _PPC_KERNEL_PPC8xx_H

#include "local_irq.h"

extern struct hw_interrupt_type ppc8xx_pic;

#endif /* _PPC_KERNEL_PPC8xx_H */
